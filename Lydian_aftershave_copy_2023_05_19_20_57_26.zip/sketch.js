let gravity = 0.98;
let stopbote=1
stopstopbote=1
let width = 400
let height = 400
class pelota {
 constructor(x,y,dx,dy,vx,vy,rad){
    this.x= x
    this.y= y
    this.dx= dx
    this.dy= dy
    this.vx= vx
    this.vy= vy
    this.rad=rad
  }  
  vectord(){
    if (stopbote===0){
    strokeWeight(1);
      let s = map(second(), 0, 60, 0, TWO_PI) - HALF_PI;
  line(90, 285, 90 + cos(s) * 50, 285 + sin(s) * 50);
      }
  } 
  tiro(){
    this.vx=30
    if (stopbote===0){
      if (keyCode=== RIGHT_ARROW){
        stopstopbote=0
    this.vy += gravity;
    this.x += this.vx*cos(45);
    this.y += this.vy*sin(45);
    }
        fill("orange");
        ellipse(this.x, this.y, this.rad, this.rad);
      }
    }  
  
  }
class pelotaredonda extends pelota{
  constructor(x,y,dx,dy,vx,vy,rad){
  super(x,y,dx,dy,vx,vy,rad)
  }  
  bota(){
      if (keyCode === LEFT_ARROW){
        stopbote=0 
        this.y=285
      }
    this.vx=0
    fill("orange");
    ellipse(this.x, this.y, this.rad, this.rad);
    this.x = this.x + this.vx * this.dx;
    this.y = this.y + this.vy * this.dy * stopbote;
  if (this.x > width - this.rad || this.y < this.rad) {
    this.dx *= -1;
  }
  if (this.y < 325 - this.rad || this.y < this.rad) {
    this.dy *= -1;
  }
    
  if (this.y > height - this.rad || this.y < this.rad) {
    this.dy *= -1;
  }
  }
}

function setup(){
    misbolas = new pelotaredonda(90,285,1,-1,3,-9.8,40);
    createCanvas(width,height);
  frameRate(30);
}

function draw(){
   background("cyan");
  strokeWeight(1);
  fill ("gray");
rect(width/2+190,height/3.75,width-390,height-100);
  fill("white");
rect(width-width/5,height/2-30,height-300,width-390);
  fill("black");
  circle(50,275,30);
  rect(45,275,10,75);
  strokeWeight(1);
  if (stopstopbote===1){
       misbolas.bota();
      }
  strokeWeight(8.5);
  line(50,347,75,380);
  line(75,380,55,400);
  strokeWeight(8);
  line(50,295,75,310);
  line(75,310,90,285);
  strokeWeight(1);
  misbolas.tiro();
  misbolas.vectord();
}